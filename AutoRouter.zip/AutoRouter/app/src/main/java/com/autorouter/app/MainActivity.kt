package com.autorouter.app

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.autorouter.app.databinding.ActivityMainBinding
import com.autorouter.app.service.OverlayService
import com.autorouter.app.service.ScreenCaptureService
import com.autorouter.app.util.PermissionHelper
import com.autorouter.app.util.Prefs

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ScreenCaptureService::class.java)
                    .putExtra(ScreenCaptureService.EXTRA_CODE, res.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_DATA, data)
            )
            Toast.makeText(this, "Screen capture shuru", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Screen capture ki ijazat nahi mili", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        permLauncher.launch(
            arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO)
        )

        b.btnOverlayPerm.setOnClickListener { PermissionHelper.openOverlaySettings(this) }
        b.btnAccessPerm.setOnClickListener { PermissionHelper.openAccessibilitySettings(this) }

        b.btnStartOverlay.setOnClickListener {
            if (!PermissionHelper.canDrawOverlays(this)) {
                Toast.makeText(this, "Pehle Overlay permission dein", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
                )
            }
        }
        b.btnStopOverlay.setOnClickListener {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }

        b.btnStartCapture.setOnClickListener {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }
        b.btnStopCapture.setOnClickListener {
            startService(
                Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        fun ok(v: Boolean) = if (v) "OK" else "BAAQI"
        b.tvStatus.text =
            "Overlay permission: ${ok(PermissionHelper.canDrawOverlays(this))}\n" +
            "Accessibility: ${ok(PermissionHelper.isAccessibilityEnabled(this))}\n" +
            "Microphone: ${ok(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == 0)}\n" +
            "Screen capture: ${if (ScreenCaptureService.running) "CHAL RAHA" else "BAND"}\n" +
            "Auto-Trade: ${if (Prefs.autoTradeEnabled) "ON" else "OFF"}"
    }
}
