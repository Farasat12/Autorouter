package com.autorouter.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.autorouter.app.MainActivity
import com.autorouter.app.R
import com.autorouter.app.engine.VoiceEngine
import com.autorouter.app.util.Prefs

class OverlayService : Service() {

    enum class BannerType(val color: Int) {
        UP(Color.parseColor("#E6138A3E")),
        DOWN(Color.parseColor("#E6C62828")),
        INFO(Color.parseColor("#E61E2A3A"))
    }

    private lateinit var wm: WindowManager
    private var buttonsView: View? = null
    private var bannerView: View? = null
    private var powerBtn: ImageButton? = null
    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { bannerView?.visibility = View.GONE }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (buttonsView == null) {
            VoiceEngine.init(this)
            addBanner()
            addButtons()
            showBanner("Auto Router", "Tayar hai. Auto-Trade abhi OFF hai.", BannerType.INFO)
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Auto Router", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Auto Router chal raha hai")
            .setContentText("Floating controls active")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun addBanner() {
        val ctx = ContextThemeWrapper(this, R.style.Theme_AutoRouter)
        val v = LayoutInflater.from(ctx).inflate(R.layout.overlay_banner, null)
        v.visibility = View.GONE
        v.setOnClickListener { v.visibility = View.GONE }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        wm.addView(v, lp)
        bannerView = v
    }

    fun showBanner(title: String, message: String, type: BannerType = BannerType.INFO) {
        handler.post {
            val v = bannerView ?: return@post
            val bg = GradientDrawable().apply {
                setColor(type.color)
                cornerRadius = 24f
            }
            v.findViewById<LinearLayout>(R.id.bannerRoot).background = bg
            v.findViewById<TextView>(R.id.bannerTitle).text = title
            v.findViewById<TextView>(R.id.bannerMessage).text = message
            v.visibility = View.VISIBLE
            handler.removeCallbacks(hideRunnable)
            handler.postDelayed(hideRunnable, 7000)
        }
    }

    private fun paintPower() {
        powerBtn?.setColorFilter(
            if (Prefs.autoTradeEnabled) Color.parseColor("#4CAF50") else Color.parseColor("#EF5350")
        )
    }

    /** Button, voice command, kahin se bhi call ho sakta hai. */
    fun setAutoTrade(on: Boolean) {
        handler.post {
            Prefs.autoTradeEnabled = on
            paintPower()
            if (on) {
                showBanner("AUTO-TRADE ON", "System active hai. Chart analysis chal raha hai.", BannerType.UP)
                VoiceEngine.speak("Auto trade chalu ho gaya")
            } else {
                showBanner("AUTO-TRADE OFF", "System pause hai. Koi trade nahi hogi.", BannerType.DOWN)
                VoiceEngine.speak("Auto trade band ho gaya")
            }
        }
    }

    private fun addButtons() {
        val ctx = ContextThemeWrapper(this, R.style.Theme_AutoRouter)
        val v = LayoutInflater.from(ctx).inflate(R.layout.overlay_buttons, null)
        val density = resources.displayMetrics.density

        val power = v.findViewById<ImageButton>(R.id.btnPower)
        val voice = v.findViewById<ImageButton>(R.id.btnVoice)
        val settings = v.findViewById<ImageButton>(R.id.btnSettings)
        powerBtn = power

        voice.setColorFilter(Color.WHITE)
        settings.setColorFilter(Color.WHITE)
        paintPower()

        power.setOnClickListener { setAutoTrade(!Prefs.autoTradeEnabled) }
        voice.setOnClickListener { VoiceEngine.listen() }
        settings.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (12 * density).toInt()
            y = (96 * density).toInt()
        }
        wm.addView(v, lp)
        buttonsView = v
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        buttonsView?.let { runCatching { wm.removeView(it) } }
        bannerView?.let { runCatching { wm.removeView(it) } }
        buttonsView = null
        bannerView = null
        powerBtn = null
        instance = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.autorouter.app.START_OVERLAY"
        const val ACTION_STOP = "com.autorouter.app.STOP_OVERLAY"
        private const val CHANNEL_ID = "autorouter_overlay"
        private const val NOTIF_ID = 101

        @Volatile var instance: OverlayService? = null
    }
}
