package com.autorouter.app.engine

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pixel-based candle reader: screenshot se hari/laal candles dhoondta hai,
 * unke close levels par Bollinger Bands (SMA20, 2 std) nikalta hai,
 * aur aakhri candle mein band se rejection dhoondta hai.
 * Price = -y (upar = zyada price).
 */
object ScreenAnalyzer {

    enum class Signal { NONE, UP, DOWN }
    data class Result(val signal: Signal, val reason: String)

    private class Candle(val x: Int, val high: Float, val low: Float,
                         val open: Float, val close: Float)

    private const val PERIOD = 20
    private const val MAX_CANDLE_W = 25

    fun analyze(bmp: Bitmap): Result {
        val w = bmp.width
        val top = (bmp.height * 0.15).toInt()
        val bottom = (bmp.height * 0.88).toInt()
        val ch = bottom - top
        if (ch < 20 || w < 50) return Result(Signal.NONE, "Screen bohat chhoti")

        val px = IntArray(w * ch)
        bmp.getPixels(px, 0, w, 0, top, w, ch)

        // 1 = green, 2 = red
        val cls = ByteArray(w * ch)
        val colG = IntArray(w)
        val colR = IntArray(w)
        for (y in 0 until ch) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                if (g > 120 && g > r + 40 && g > b + 40) { cls[y * w + x] = 1; colG[x]++ }
                else if (r > 150 && r > g + 60 && r > b + 60) { cls[y * w + x] = 2; colR[x]++ }
            }
        }

        val candles = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            val kind = when {
                colG[x] > 0 && colG[x] >= colR[x] -> 1
                colR[x] > 0 -> 2
                else -> 0
            }
            if (kind == 0) { x++; continue }
            var e = x
            while (e + 1 < w && (if (kind == 1) colG[e + 1] else colR[e + 1]) > 0) e++
            val width = e - x + 1
            if (width in 2..MAX_CANDLE_W) buildCandle(cls, w, ch, x, e, kind)?.let { candles.add(it) }
            x = e + 1
        }

        if (candles.size < PERIOD + 1)
            return Result(Signal.NONE, "Chart nahi mila (${candles.size} candles)")

        val last20 = candles.takeLast(PERIOD).map { it.close }
        val mean = last20.sum() / PERIOD
        val std = sqrt(last20.map { (it - mean) * (it - mean) }.sum() / PERIOD)
        if (std < 2f) return Result(Signal.NONE, "Market flat hai")
        val upper = mean + 2 * std
        val lower = mean - 2 * std

        val c = candles.last()
        val bodyHigh = max(c.open, c.close)
        val bodyLow = min(c.open, c.close)
        val body = max(bodyHigh - bodyLow, 1f)
        val upperWick = c.high - bodyHigh
        val lowerWick = bodyLow - c.low
        val tol = 1.5f

        if (c.high >= upper - tol && upperWick >= body && c.close < upper)
            return Result(Signal.DOWN, "Upper Bollinger Band par price reject ho raha tha")
        if (c.low <= lower + tol && lowerWick >= body && c.close > lower)
            return Result(Signal.UP, "Lower Bollinger Band par price reject ho raha tha")
        return Result(Signal.NONE, "Koi rejection nahi")
    }

    private fun buildCandle(cls: ByteArray, w: Int, ch: Int, xs: Int, xe: Int, kind: Int): Candle? {
        val width = xe - xs + 1
        var first = -1
        var lastY = -1
        var bodyTop = -1
        var bodyBottom = -1
        val need = max(2, (width * 0.6f).toInt())
        for (y in 0 until ch) {
            var n = 0
            for (xx in xs..xe) if (cls[y * w + xx].toInt() == kind) n++
            if (n > 0) { if (first < 0) first = y; lastY = y }
            if (n >= need) { if (bodyTop < 0) bodyTop = y; bodyBottom = y }
        }
        if (first < 0 || lastY - first < 2 || lastY - first > ch / 2) return null
        if (bodyTop < 0) { bodyTop = (first + lastY) / 2; bodyBottom = bodyTop }
        val open: Float
        val close: Float
        if (kind == 1) { open = -bodyBottom.toFloat(); close = -bodyTop.toFloat() }
        else { open = -bodyTop.toFloat(); close = -bodyBottom.toFloat() }
        return Candle(xs, -first.toFloat(), -lastY.toFloat(), open, close)
    }
}
