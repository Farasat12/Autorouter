package com.autorouter.app.engine

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import com.autorouter.app.service.AutoClickService
import com.autorouter.app.service.OverlayService
import com.autorouter.app.service.ScreenCaptureService
import com.autorouter.app.util.Prefs
import java.util.Locale

object VoiceEngine {

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var appCtx: Context? = null
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    private val ON_WORDS = setOf("on", "start", "chalu", "shuru", "chalao", "चालू", "शुरू", "चालु")
    private val OFF_WORDS = setOf("off", "stop", "band", "ruko", "rok", "बंद", "रुको", "रोको")
    private val STATUS_WORDS = setOf("status", "haal", "hal", "batao", "हाल", "स्थिति", "बताओ")

    fun init(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        appCtx = app
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                val r = t.setLanguage(Locale("en", "IN"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale.US)
                }
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "autorouter")
    }

    fun listen() {
        main.post {
            val ctx = appCtx ?: return@post
            val overlay = OverlayService.instance
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                overlay?.showBanner("Voice", "Microphone permission nahi hai. App kholkar dein.")
                return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                overlay?.showBanner("Voice", "Is phone par speech recognition maujood nahi.")
                return@post
            }
            recognizer?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
            recognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {
                    overlay?.showBanner("Sun raha hoon...", "Bolein: chalu / band / status")
                }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    handle(list?.firstOrNull() ?: "")
                    sr.destroy(); recognizer = null
                }
                override fun onError(error: Int) {
                    overlay?.showBanner("Voice", "Awaaz samajh nahi aayi, dobara try karein.")
                    sr.destroy(); recognizer = null
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            sr.startListening(i)
        }
    }

    private fun handle(text: String) {
        val overlay = OverlayService.instance
        val tokens = text.lowercase().split(Regex("[^\\p{L}\\p{M}]+")).filter { it.isNotEmpty() }.toSet()
        overlay?.showBanner("Voice command", "\"$text\"")
        when {
            tokens.any { it in OFF_WORDS } -> overlay?.setAutoTrade(false)
            tokens.any { it in ON_WORDS } -> overlay?.setAutoTrade(true)
            tokens.any { it in STATUS_WORDS } -> {
                val msg = "Auto trade ${if (Prefs.autoTradeEnabled) "ON" else "OFF"}. " +
                    "Accessibility ${if (AutoClickService.instance != null) "ON" else "OFF"}. " +
                    "Screen capture ${if (ScreenCaptureService.running) "ON" else "OFF"}."
                overlay?.showBanner("Status", msg)
                speak(msg)
            }
            else -> speak("Command samajh nahi aayi")
        }
    }
}
