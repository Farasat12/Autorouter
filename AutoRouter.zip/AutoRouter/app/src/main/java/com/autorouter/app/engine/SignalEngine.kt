package com.autorouter.app.engine

import com.autorouter.app.service.AutoClickService
import com.autorouter.app.service.OverlayService
import com.autorouter.app.util.Prefs

object SignalEngine {

    private const val COOLDOWN_MS = 60_000L
    @Volatile private var lastTradeAt = 0L

    fun onResult(r: ScreenAnalyzer.Result) {
        if (!Prefs.autoTradeEnabled) return
        if (r.signal == ScreenAnalyzer.Signal.NONE) return

        val now = System.currentTimeMillis()
        if (now - lastTradeAt < COOLDOWN_MS) return
        lastTradeAt = now

        val up = r.signal == ScreenAnalyzer.Signal.UP
        val word = if (up) "UP" else "DOWN"
        val type = if (up) OverlayService.BannerType.UP else OverlayService.BannerType.DOWN
        val svc = AutoClickService.instance

        if (svc == null) {
            OverlayService.instance?.showBanner(
                "$word signal (click nahi hua)",
                "Accessibility ON nahi hai. ${r.reason}", type
            )
            VoiceEngine.speak("$word signal mila lekin accessibility band hai")
            return
        }

        svc.clickTrade(up) { ok ->
            if (ok) {
                OverlayService.instance?.showBanner("$word ki trade di", r.reason, type)
                VoiceEngine.speak("$word ki trade di. ${r.reason}")
            } else {
                OverlayService.instance?.showBanner(
                    "$word signal, button nahi mila", "Screen par $word button nazar nahi aaya.", type
                )
                VoiceEngine.speak("$word button nahi mila")
            }
        }
    }
}
