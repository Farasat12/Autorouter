package com.autorouter.app.util

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("autorouter", Context.MODE_PRIVATE)
        }
    }

    var autoTradeEnabled: Boolean
        get() = sp.getBoolean("auto_trade", false)
        set(v) = sp.edit().putBoolean("auto_trade", v).apply()
}
