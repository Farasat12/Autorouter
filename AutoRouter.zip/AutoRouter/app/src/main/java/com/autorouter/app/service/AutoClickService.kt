package com.autorouter.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoClickService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    /** up=true -> Up/Higher/Call/Buy button, warna Down/Lower/Put/Sell. */
    fun clickTrade(up: Boolean, done: (Boolean) -> Unit) {
        Handler(Looper.getMainLooper()).post {
            val labels = if (up) UP_LABELS else DOWN_LABELS
            val node = findButton(labels)
            done(if (node != null) performTap(node) else false)
        }
    }

    private fun findButton(labels: List<String>): AccessibilityNodeInfo? {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        windows?.forEach { w -> w.root?.let { roots.add(it) } }
        rootInActiveWindow?.let { roots.add(it) }
        for (r in roots) {
            if (r.packageName?.toString() == packageName) continue // apna overlay na click ho
            search(r, labels)?.let { return it }
        }
        return null
    }

    private fun search(n: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        if (n.isVisibleToUser) {
            val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "")
                .trim().lowercase()
            if (t.isNotEmpty() && labels.any { t == it || t.startsWith("$it ") }) return n
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            search(c, labels)?.let { return it }
        }
        return null
    }

    private fun performTap(node: AccessibilityNodeInfo): Boolean {
        var p: AccessibilityNodeInfo? = node
        while (p != null) {
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            p = p.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    companion object {
        @Volatile var instance: AutoClickService? = null
        val UP_LABELS = listOf("up", "higher", "call", "buy", "above", "high")
        val DOWN_LABELS = listOf("down", "lower", "put", "sell", "below", "low")
    }
}
