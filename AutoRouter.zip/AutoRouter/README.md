# Auto Router
GitHub par push karein -> Actions tab -> APK build -> Releases se download.
Pehle demo account par test karein.
